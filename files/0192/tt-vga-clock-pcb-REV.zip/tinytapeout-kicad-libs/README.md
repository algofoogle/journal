# tinytapeout-kicad-libs
Symbols and footprints created to support TinyTapeout boards and extensions
