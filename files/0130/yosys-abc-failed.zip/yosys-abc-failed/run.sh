#!/usr/bin/bash

yosys-abc -s -f abc.script

